                        ____  ____   ____  
                       |  _ \|  _ \ / __ \ 
  _   _ _   _ _ __ ___ | |_) | |_) | |  | |
 | | | | | | | '_ ` _ \|  _ <|  _ <| |  | |
 | |_| | |_| | | | | | | |_) | |_) | |__| |
  \__, |\__,_|_| |_| |_|____/|____/ \___\_\
   __/ |                                   
  |___/                                    
                   Lick your lips and fuck a duck, did you write your protocols in English?

SITE:
	https://r4p3.net

README:
yumBBQ is mmBBQ packaged specifically for TeamSpeak 3 protocol analysis on behalf of the R4P3 community.

mmBBQ injects a scriptable Lua API to a win32 process.
It is easy to use, there are no dependencies and only
little knowledge required.


USAGE:
	1 unzip mmBBQ archive to a location of your choice
	2 make sure your process is running
	3 run mmBBQ's START.bat
	4 (OPTIONAL) modify your config.lua to do whatever you please