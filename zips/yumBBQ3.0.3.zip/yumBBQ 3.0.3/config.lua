--- mmBBQ configuration for all targets
--
-- It contains LUA syntax, so you may also
-- add additional code directly in this file.
--
-- This file basically defines TARGETS configuration and an optional APIKEY.
-- It may also be used to perform any operation.
--
module("config", package.seeall);


----------------------
-- TARGET CONFIGURATION
----------------------
-- A host process where mmBBQ injects is called a `target`. You can define any injection target you like. 
-- When running `START.bat` the dll starts a temporary Lua VM to determine which targets are defined.
-- Targets defined here are available for the injector. Has to be gobally defined like that:
--	_G.TARGETS = {
--		{	                                                   
--          ["name"]  = "np",                                  -- the targets shorthandle name. used as global `TARGET` and `PREFIX`.
--			["exe"]   = "notepad.exe",                         -- the executables filename
--			["title"] = "Notepad",	                           -- OPTIONAL arbitrary, but should be the main windows title
--			["ver"]   = "6.1",                                 -- OPTIONAL an arbritrary string describing the targets version number
--			["md5"]   = "0123456789abcdef0123456789abcdef",    -- OPTIONAL md5sum of process executable. checked before attaching
--			["lua"]   = "notepad.lua",                         -- OPTIONAL target bootsrap file - called with `dofile()`
--			["cfg"]   = "config_np",                           -- OPTIONAL target config module - called with `require()`
--		},
--		
--		-- ...                                                 -- add as many targets as you like
--	}
_G.TARGETS = {	
	--[[ EXAMPLE TARGET PROJECTS INCLUDED IN THE SDK ]]--
	{
		["name"]  = "hell",
		["exe"]   = "hellgate.exe",
		["title"] = "Hellgate (x86 DX9)",
		["ver"]   = "2.0.0.3",
		["md5"]   = "622d0723d5255913ce39c41c363cc818",
		["lua"]   = "hell_target.lua",
		["cfg"]   = "config_hell",
	},
	
	{
		["name"]  = "myth",
		["exe"]   = "Myth.exe",
		["title"] = "Mythos",
		["ver"]   = "2.0.17.6535",
		["md5"]   = "30f2d953b8c3c4cd6241d1060976df7c",
		["lua"]   = "myth_target.lua",
		["cfg"]   = "config_myth",
	},
	
	{
		["name"]  = "sro",
		["exe"]   = "sro_client.exe",
		["title"] = "Silkroad",
		["ver"]   = "todo",
		["md5"]   = "0477d265af6d8bcd0565df722a2021cf",
		["lua"]   = "sro_target.lua",
		["cfg"]   = "config_sro",
	},
	
	{
		["name"]  = "poex",
		["exe"]   = "Client.exe",
		["title"] = "Path of Exile",
		["ver"]   = "todo",
		["md5"]   = "08380a8e8f21fa4fac25fa2f75193c30",
		["lua"]   = "poex_target.lua",
		["cfg"]   = "config_poex",
	},
	
	{
		["name"]  = "odbg",
		["exe"]   = "ollydbg.exe",
		["title"] = "OllyDBG",
		["ver"]   = "todo",
		["md5"]   = "5be972e8d245dab24c15a93ad67f90ed",
		["lua"]   = "odbg_target.lua",
		["cfg"]   = "config_odbg",
	},
	
	-- ... add more targets if you like
}

-- only continue if a TARGET is known (already injected -> called from mmbbq.lua)
if not _G.TARGET then return end

--[[ PLACE YOUR LAZY STUFF HERE 
all stuff below this line is executed for any target. 
If you are doing a quick hack for only one target anything can be added here.
You dont need a special config.lua or target.lua ]]--

--require("common/asmcall");
--asmcall.cdecl(getProcAddress("user32", "MessageBoxA"), 0, "Hello World!", "Title", 0)

-- MSDN: int WSARecvFrom( __in     SOCKET s, __inout  LPWSABUF lpBuffers, __in     DWORD dwBufferCount, __out    LPDWORD lpNumberOfBytesRecvd, ... );
local function wsa_recv(context)
    local buflen = context.arg32(2, "uint32_t**")[0];
    local buf = context.arg32(2, "char**")[1];
    local recv = context.arg32(4, "uint32_t*")[0];
    if recv > 0 then
        printf("[RECV] 0x%X", recv);
        hexdump(buf, recv);
    end
end
codecave.inject(nil, getProcAddress("ws2_32", "WSARecvFrom"), wsa_recv, codecave.INTERCEPT_RETURN)