###USAGE###
Extract the contents of this archive to your TeamSpeak 3 directory.
ex:
C:\Program Files (x86)\TeamSpeak 3 Client
or
C:\Program Files\TeamSpeak 3 Client

###INFO###
Check out http://r4p3.net/ for security threats, information and help.

###THANKS TO###
Kaptan647
U+115F
Supervisor
hASVAN1

###Archive Author###
Asphyxia